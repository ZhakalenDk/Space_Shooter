﻿using UnityEngine;
using System.Collections;


public class $safeitemname$ : MonoBehaviour
{
    #region Variables
    #endregion

    #region BuiltIn methods
    /// <summary>
    /// Is called at the very first frame the object is instantiated in the scene
    /// </summary>
    private void Start ()
    {
    }

    /// <summary>
    /// Is called once every frame
    /// </summary>
    private void Update ()
    {

    }
    #endregion

    #region Custom methods

    #endregion
}